<section class="form-bottom">
	<div class="inner-box">
		<h2><?php block_field('title');?></h2>
		<p><?php block_field('copy'); ?></p>
		<form>
			<div class="contact" id="contact-form">
				<div class="contact-input"> 
					<label for="contact-first_name">First Name</label> 
					<input type="text" name="contact-first_name" placeholder="First Name" value="">
				</div>
				<div class="contact-input"> 
					<label for="contact-last_name">Last Name</label> 
					<input type="text" name="contact-last_name" placeholder="Last Name" value=""> 
				</div>
				<div class="contact-input"> 
					<label for="contact-email">Email</label> 
					<input type="text" name="contact-email" placeholder="Email" value=""> 
				</div>
				<div class="contact-input"> 
					<label for="contact-phone">Phone Number</label> 
					<input type="text" name="contact-phone" placeholder="Phone Number" value=""> 
				</div>
				<div class="contact-input"> 
					<label for="contact-phone">Home Address</label> 
					<input type="text" name="contact-address" placeholder="Home Address" value=""> 
				</div>
				<div class="contact-input"> 
					<label for="contact-postal_code">Postal Code</label> 
					<input type="text" name="contact-postal_code" placeholder="Postal Code" value=""> 
				</div>
				<div class="contact-input checkbox top"> 
					<input type="checkbox" name="check-type" value="tac-verify">
					<span>Terms &amp; Conditions*<br>By proceeding you agree to the terms and conditions.</span> 
				</div>
				<div class="cta"> 
					<a href="javascript:;" id="next-btn" class="short" onclick="javascript:form_submit(this)">Submit</a> 
				</div>
			</div>
		</form>
	</div>
</section>
<section class="price-block-module">
	<div class="inner-box">
		<div class="price-block">
			<span class="price"><sup>$</sup><?php block_field('price'); ?><sup>99</sup></span><span class="small-month">/mo</span>
		</div>
		<div class="text-side">
			<p class="title"><?php block_field('title');?></p>
			<div class="duration"><?php block_field('duration');?></div>
		</div>
	</div>
</section>
// APPLICATION CODE HERE
jQuery(document).ready(function(){
	jQuery('.testimonials .slider').slick({
		dots: true,
  		infinite: true,
  		speed: 300,
  		slidesToShow: 1,
  		adaptiveHeight: true
	});
	jQuery('.accordion').on('click', function(e){
		e.preventDefault();
		jQuery(this).parents('.item').toggleClass('open');
	});
	jQuery('#tab-block li').on('click', function(){
		jQuery('.category-list').removeClass('heating').removeClass('cooling').removeClass('water-treatment').removeClass('water-heating').removeClass('air-filtration');
		var category = jQuery(this).attr('id');
		jQuery('.category-list').addClass(category);
	});
});
<?php
/**
 * Template Name: Product Page Template
 * Template Post Type: products
 *
 * This is the wordpress posts template. It contains a list of all the posts and media to date.
 *
 * @package SG-Base-Theme
 * @subpackage SimplyGreen-2020
 * @since 2020
 */
?>
<?php get_header(); ?>
<?php $dir = get_stylesheet_directory_uri(); ?>

<!-- The Loop -->

<section class="single-product">
    <div class="inner-box">
        <h1><?php the_title(); ?></h1>
    </div>
    <?php 
            if ( have_posts() ) : while ( have_posts() ) : the_post();
                $meta = get_post_meta( $post->ID, 'meta', true ); 
                ?>

    <div class="half-and-half-products" data-category="<?php sps_category(); ?>">
        <div class="text-side"><div class="copy">
            <?php echo '<img src="'.$meta['thumbnail_url'].'" class="prod-logo"/>' ?>
            <p><?php the_content();?></p>
        </div></div>
        <div class="image-side"><?php the_post_thumbnail();?></div>
    </div>      
    <?php endwhile; endif; wp_reset_postdata(); ?>
</section>

<section class="category-list  <?php sps_category(); ?>">
    <div class="inner-box">
        <h2>Related Products</h2>
        <nav id="tab-block">
            <ul>
                <li id="heating">Heating</li>
                <li id="cooling">Cooling</li>
                <li id="air-filtration">Air Filtration</li>
                <li id="water-heating">Water Heating</li>
                <li id="water-treatment">Water Treatment</li>
            </ul>
        </nav>
        <div class="product-grid">
    <?php 
        $args = array(
            'post_type' => 'products',
            'posts_per_page' => -1,
        );

        $product_loop = new WP_Query( $args );

            if ( $product_loop->have_posts() ) : while ( $product_loop->have_posts() ) : $product_loop->the_post();
                $meta = get_post_meta( $post->ID, 'meta', true ); ?>
    <div class="item <?php sps_category(); ?>">
        <div class="text-side">
            <?php echo '<img src="'.$meta['thumbnail_url'].'" class="prod-logo"/>' ?>
            <h3><?php the_title(); ?></h3>
            <p><?php echo excerpt(10);?></p>        
            <div class="cta-block"><a href="<?php the_permalink(); ?>">View details ›</a></div>                
        </div>
        <div class="image-side"><?php the_post_thumbnail();?></div>
    </div>      
    <?php endwhile; endif; wp_reset_postdata(); ?>
</div>
</div>
</section>

<?php get_footer(); ?>